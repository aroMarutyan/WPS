import { BOT } from './src/telegramBot';
export function handler() {
  BOT.sendMessage('Bot is working!');
};
